<?php

include("../global/virtualQueueIni.php");
$cfg = VirtualQueueIni::getInstance();

$link = mysql_connect($cfg->getServer(), $cfg->getUsername(), $cfg->getPassword());
if (!$link) {
    die('Not connected : ' . mysql_error());
}

// make foo the current db
$db_selected = mysql_select_db($cfg->getDatabase(), $link);
if (!$db_selected) {
    die('Can\'t use foo : ' . mysql_error());
}


$seg_codigo = $_GET["seg_codigo"];
$eje_codigo = $_GET["eje_codigo"];
$accion = $_GET["accion"];
$nemo = $_GET["nemo"];

if ($accion == "Atender") {
    $sql = "UPDATE seguimiento 
            SET eje_codigo = '$eje_codigo', seg_fecatencion = CURRENT_TIMESTAMP(), seg_atendido = 1 
            where seg_codigo ='$seg_codigo'";
} else {
    $sql = "UPDATE seguimiento 
            SET eje_codigo = '$eje_codigo', seg_fecfinatencion = CURRENT_TIMESTAMP(), seg_atendido = 2
            where seg_codigo ='$seg_codigo'";
}
mysql_query($sql);

mysql_close($link);
?>
