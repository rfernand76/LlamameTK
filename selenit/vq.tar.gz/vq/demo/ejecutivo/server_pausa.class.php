	<?php  
        include("../global/virtualQueueIni.php");
        $cfg = VirtualQueueIni::getInstance();
    
	    $link = mysql_connect($cfg->getServer(), $cfg->getUsername(), $cfg->getPassword());
		if (!$link) {
			die('Not connected : ' . mysql_error());
		}
		
		// make foo the current db
		$db_selected = mysql_select_db($cfg->getDatabase(), $link);
		if (!$db_selected) {
			die ('Can\'t use foo : ' . mysql_error());
		}


		$accion=$_GET["accion"];
        $eje_codigo=$_GET["eje_codigo"];

        if($accion == "Pausar"){
		$sql =  "INSERT INTO pausa(".
                "eje_codigo, pau_inicio".
                ")".
                "VALUES (".
                "'$eje_codigo', CURRENT_TIMESTAMP() ".
                ")";

            mysql_query($sql);
            $pau_codigo = mysql_insert_id();
            echo $pau_codigo;
        }else{
            $pau_codigo=$_GET["pau_codigo"];
            
		    $sql = "UPDATE pausa SET pau_fin = CURRENT_TIMESTAMP() where pau_codigo = '$pau_codigo'";
		    mysql_query($sql);
        }

        mysql_close($link);
	?>
