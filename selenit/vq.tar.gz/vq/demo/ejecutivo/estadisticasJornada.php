<?php 
    include("../global/virtualQueueIni.php");
    include("../global/Service.php");

    $service = Service::getInstance();
    if($service->isLoggin()){
        $HORA_COMIENZO  = $POST["HORA_COMIENZO"];
        $cfg = VirtualQueueIni::getInstance();

   	    $link = mysql_connect($cfg->getServer(), $cfg->getUsername(), $cfg->getPassword());
	    if (!$link) {
            die('Not connected : ' . mysql_error());
        }
        $db_selected = mysql_select_db($cfg->getDatabase(), $link);

        $estadisticasJornada = $service->estadisticasJornada($HORA_COMIENZO);
        echo json_encode($estadisticasJornada); 
        mysql_close($link);
    }else{
        echo "Error, la session se ha perdido"; 
    }
?>
