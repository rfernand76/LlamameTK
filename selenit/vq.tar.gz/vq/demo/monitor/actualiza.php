<table class="tabla" id="tabla" cellspacing="0"  cellpadding="0">
                <tr class="header">
                    <td align="center">Caja</td>
                    <td align="center">Turno</td>
                </tr>

                <?php 
                    include("../global/virtualQueueIni.php");
                    $cfg = VirtualQueueIni::getInstance();
		            $link = mysql_connect($cfg->getServer(), $cfg->getUsername(), $cfg->getPassword());
		            if (!$link) {
			            die('Not connected : ' . mysql_error());
		            }
		
		            // make foo the current db
		            $db_selected = mysql_select_db($cfg->getDatabase(), $link);
		            if (!$db_selected) {
			            die ('Can\'t use foo : ' . mysql_error());
		            }
                    $sql = "select fil_nemo, fil_ta, eje_modulo from fila";
                    $result = mysql_query($sql);


	                while ($fila = mysql_fetch_assoc($result))
	                {
                        $numero = $fila["fil_nemo"]. " ". $fila["fil_ta"];
		                echo 
                            '<tr class="muestra"><td align="center">'.$fila["eje_modulo"].'</td><td align="center">'.$numero.'</td></tr>';
	                }
                    mysql_close($link);
                ?>
</table>
