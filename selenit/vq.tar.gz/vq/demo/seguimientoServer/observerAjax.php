<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//include("virtualQueueIni.php");
//$cfg = VirtualQueueIni::getInstance();
$parametros = $_SERVER['QUERY_STRING'];

$url1 = "http://54.94.203.188:8888/consulta?$parametros";
//echo $url1;
$r = file_get_contents($url1, false);
echo $r;

?>
