node VQServer.js&
node VQHttpServer.js&
