nohup node VQServer.js&
nohup node VQHttpServer.js&
