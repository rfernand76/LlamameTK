<?php 
    @session_start();
    $_SESSION['usuario']  = '';
    $_SESSION['password'] = '';
    include("index.php");
?>
