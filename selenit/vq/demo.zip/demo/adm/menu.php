                    <li id="administrar"> <a href="administrar.php"> Administrar Jornadas</a></li>
                    <li id="filas"> <a href="filas.php"> Filas</a></li>
                    <li id="usuarios"> <a href="usuarios.php"> Usuarios</a></li>
                    <li id="modulos"> <a href="modulos.php"> Modulos</a></li>
                    <!--li id="parametros"> <a href="parametros.php"> Parametros</a></li-->


