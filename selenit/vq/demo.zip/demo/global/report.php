<?php 
    require 'php-excel-v1.1-20090910/php-excel.class.php';
    include("../global/virtualQueueIni.php");
    class Report {
        protected $link = null;

        public static function execute($c){
            $method = Report::getPostAndGet("method");
            $params = Report::getPostAndGet("params");
            $reflector = new ReflectionClass($c);
            $obj = $reflector->newInstance();
            $m = $reflector->getMethod($method); 
            $data = $m->invoke($obj, $params);
            return $data;
        }

        public static function getPostAndGet($name){
            $ret = $_POST[$name];
            if($ret == ""){
                $ret=$_GET[$name];
            }
            return $ret;
        }

        function getOrder(){
	        $sortname = isset($_POST['sortname']) ? $_POST['sortname'] : ''; 
	        $sortorder = isset($_POST['sortorder']) ? $_POST['sortorder'] : ''; 
            $order = "";
            if($sortname != ''){
                $order = "order by $sortname $sortorder $query";
            }
            return $order;
        }

        function getLimit(){
            $page = isset($_POST['page']) ? $_POST['page'] : 1;
	        $rp = isset($_POST['rp']) ? $_POST['rp'] : 10; 
            $inicio = ($page*$rp)-$rp;
            $fin=     ($inicio)+$rp;

            $limit = "limit $inicio, $fin";
            return $limit;
        }

        function count($s){
            $sql = "select count(1) c from (" .$s. ") a";

            $result = $this->query($sql);
            $fila = mysql_fetch_assoc($result);
            $c = $fila["c"];

            return $c;
        }

        function close($link){
            mysql_close($link);
        }

        function connect(){
            if($this->link == null){
                $cfg = VirtualQueueIni::getInstance();
                $this->link = mysql_connect($cfg->getServer(), $cfg->getUsername(), $cfg->getPassword());
                $db_selected = mysql_select_db($cfg->getDatabase(), $this->link);
            }
        }

        function query($sql){
            $result = mysql_query($sql);
            return $result;
        }

        function getParams(){
            $params = $params = Report::getPostAndGet("params");
            $parametros = null;
            if($params != ""){
                $parametros = json_decode($params);
            }
            return $parametros;
        }

        function create(){
            $rp = isset($_POST['rp']) ? $_POST['rp'] : 10;
            $page = isset($_POST['page']) ? $_POST['page'] : 1; 

            $this->connect();

            $sql = $this->getSql();
            $sqlCount = $this->getSqlForReport();
            $total = $this->count($sqlCount);
            $result = $this->query($sql);

            $jsonData = array('page'=>$page,'total'=>$total,'rp'=>$rp,'rows'=>array());
            $num_fields=mysql_num_fields($result);

            while ($fila = mysql_fetch_row($result))
            {
                $list = array();
                for($i=0; $i<$num_fields; $i++){
                    $v = $fila[$i];
                    array_push($list, $v);
                }
                
                $entry = array('cell' => $list); 
                $jsonData['rows'][] = $entry;
            }
            $this->close();
            echo json_encode($jsonData); 
        }


        function sqlAnd($parametros, $campo){
            $and = "";
            if($parametros->key == "dthoy"){
                $and = "AND $campo > CURRENT_DATE()";
            }else if($parametros->key == "dtayer"){
                $and = "AND $campo BETWEEN DATE_ADD(CURDATE(), INTERVAL -1 day) AND CURDATE()";
            }else if($parametros->key == "dtsemana"){
                $and = "AND $campo > DATE_ADD(CURDATE(), INTERVAL -7 day)";
            }else if($parametros->key == "dtmes"){
                $and = "AND $campo > DATE_ADD(CURDATE(), INTERVAL -30 day)";
            }else if($parametros->key == "dtrango"){
                $desde = $parametros->desde;
                $hasta = $parametros->hasta;
                $and = "AND $campo BETWEEN '$desde' AND '$hasta'";
            }
            return $and;
        }

        function exportToExcel(){
            $this->connect();

            $sql = $this->getSqlForReport();
            $result = $this->query($sql);
            $num_fields=mysql_num_fields($result);
            $jsonHeader = Report::getPostAndGet("jsonHeader");
            $parametros = json_decode($jsonHeader);
            
            $title = $parametros->title;
            if($title == ""){
                $title = "Reporte";
            }
            
            $xls = new Excel_XML('UTF-8', false, $title);
            
            $data = array();
            $encabezado = array($title);
            array_push($data, $encabezado);
            array_push($data,array());
            
            if($parametros->colModel != undefined && $parametros->colModel != null  && $parametros->colModel != ""){
                $titulos = array();
                foreach($parametros->colModel as $key => $value) {
                    array_push($titulos, $value->display);
                }
                array_push($data, $titulos);
            }

            while ($fila = mysql_fetch_row($result))
            {
                $list = array();
                for($i=0; $i<$num_fields; $i++){
                    $v = $fila[$i];
                    array_push($list, $v);
                }
                array_push($data, $list);
            }

            $xls->addArray($data);
            $this->close();
            $xls->generateXML($title);
        }
    }
?>
