<?php 
class Field{
    public $display = "";
    public $name = "";
    public $width = "";
    public $sortable = false;
    public $align = "center";
}
?>
