<!DOCTYPE html>
<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
<meta http-equiv="Pragma" content="no-cache">

<html lang="es">
    <head>
        <title>Selenit - Seguimiento de atención</title>
        <meta name="description" content="Seguimiento de atención"/>
        <meta charset="utf-8">
        <meta name="viewport" content="width=500, initial-scale=1">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1">
        <meta name="viewport" content="width=device-width, user-scalable=no">
            
        <script src="/js/jquery-ui-1.9.1.custom/js/jquery-1.8.2.js"></script>
        <link rel="stylesheet" href="style-seguimiento.css?a=<?php echo time()?>" type="text/css" media="all">
        

<script type="text/javascript">
    <?php
        $nemo = $_GET["nemo"];
        $miNumero = $_GET["ut"];

        $seg_codigo = $_GET["seg_codigo"];
        $token = $_GET["token"];
        $codigoManual = $_GET["codigoManual"];
    ?>
    
    $(window).load(
        function() {
            if('<?php echo $codigoManual?>' !== ""){
                connect();
            }else{
                var json = {codigo:""};
                solicitar(json);
            }
            resize(); 
        }
    );

    var ws = null;
    var host = "54.94.203.188";
    var portWS = "1337";
    var portHttp = "8888";
    var timeRefresh = "10000";
    
    function connect(){
        var c = connectWS();
        if(!c){
            if('<?php echo $codigoManual?>' !== ""){
                alert("Su dispositivo no soporta html5 (con tecnologia de resfresco automatico), por lo que el sistema se auto refrescara con tecnologia ajax (anterior).  Si la informacion no se refresca adecuadamente, se sugerimos refrescar manualmente desde el navegador");
            }
            conectAjax();
        }
    }
    
    var muestraAdvertencia = true;
    function conectAjax(){
        var msg = getMsg();
        var json = JSON.stringify(msg);
        var url = "observerAjax.php?data="+json;
                $.ajax({
                    url: url,
                    async: true,
                    timeout: 2000
                }).done(function(html) {
                    if(html !== ""){
                        setConected();

                        try{
                            var data = JSON.parse(html);
                            addMessage(data);
                            
                            if(reconect){
                                muestraAdvertencia = true;
                                setTimeout(function(){ conectAjax() }, timeRefresh);
                            }
                        }catch(e){
                            setAjaxError();
                        }
                    }
                }).fail(function(html) {
                    setAjaxError();
                })
                ;
    }
    
    function setAjaxError(){
                    if(muestraAdvertencia){
                        setDisconected();
                    }
                    
                    muestraAdvertencia = false;
                    if(reconect){
                        setTimeout(function(){ conectAjax() }, timeRefresh);
                    }
    }
    
    
    function connectWS() {
        var URL = "ws://"+host+":"+portWS+"";
        if ('WebSocket' in window) {
            ws = new WebSocket(URL);
        } else if ('MozWebSocket' in window) {
            ws = new MozWebSocket(URL);
            return true;
        } else {
            return false;
        }
        
        ws.onopen = function () {
            setConected();
            // pintamos mensaje
            setObsever();
        };
        ws.onmessage = function (event) {
            var data = JSON.parse(event.data);
            addMessage(data);
        };
        ws.onclose = function () {
            if(reconect){
                setDisconected();
                setTimeout(function(){ connectWS() }, 3000);
            }
        };
       
        return true;
    }
    
    function setConected(){
        $(".status").html("<img height='30' width='30' src='14016.png'><p><img height='30' width='30' style='display:none' src='no.png'></img></p>");
    }
    
    function setDisconected(){
        $(".status").html("<p>NO</p>");
    }
    
    var reconect = true;
    function disconnect() {
        reconect = false;
        $(".status").css("display", "none");
        
        if (ws !== null) {
            ws.close();
            ws = null;
        }
    }
    
    function getMsg(){
        var msg = {
            message: "/observer",
            date: Date.now(),
            nemo: '<?php echo $nemo?>',
            miNumero: '<?php echo $miNumero?>',
            seg_codigo: '<?php echo $seg_codigo?>',
            token: '<?php echo $token?>',
            codigoManual: '<?php echo $codigoManual?>'
        };
        
        return msg;
    }

    function setObsever() {
        var msg = getMsg();
        var json = JSON.stringify(msg);
        ws.send(json);
    }

    function addMessage(json){
        if(json !== "" && json.accion){
            var js = json.accion + "(json)";
            eval(js);
        }
    }
    
    var miNumero = 0;
    function activar(json){
        $("#contenido").css("display", "block");
        $("#idNumero").html(json.numero);
        $("#idMiModulo").html(json.modulo);
        $("#miNumero").html(json.letra + " "+ json.miNumero);
        miNumero = json.miNumero;
        verificaEstado(json);
    }
    
    function update(json){
        $("#contenido").css("display", "block");
        $("#idNumero").html(json.numero);
        $("#idMiModulo").html(json.modulo);
        verificaEstado(json);
    }
    
    var sigue = true;
    function solicitar(json) {
        $(".status").css("display", "none");
        
        $("#contenido").css("display", "none");
        var html = "<p>Numero no encontrado:</p>"
        + "<input maxlength='15' value='"+json.codigo+"' id='codigoManual' style='font-size:24px;width:200px; type='text' name='codigoManual'/> <input style='height:30px' type='button' value='Aceptar' onClick='submitCodigo();'/><br/>";
                
        $('#info').html(html);
        reconect = false;
    }
    
    
    function verificaEstado(json){
        if(miNumero <= json.numero){
            var suturno = $("#suturno");
            suturno.html("Diríjase al módulo " + json.miModulo);
            suturno.addClass("llamado");
            suturno.css("width", (getWidth()-50) + "px");
            disconnect();
        }
    }
                 
    function submitCodigo(){
        var codigoManual = $("#codigoManual").val();
        var url = window.location.href;
        var instr = url.indexOf("?");
        if(instr > 0){
            url = url.substr(0, instr-1);
        }
        url = "";
        window.parent.location = url + "?codigoManual="+codigoManual;
    }
            
    function resize(){
        var publi = $("#publi");
        var screen_height = getHeight();
                
        var top = 85;
        var h = $("#info").css("height");
        var info_height = (h.substr(0, h.length -2)*1);
                
        if(screen_height < info_height+top){
            publi.css("top", (1)+"px");
            return;
        }
                
                
        publi.css("top", (screen_height-321)+"px");
    }
            
    function getWidth()
    {
        var x = 0;
        if (self.innerWidth){
                x = self.innerWidth;
        }else if (document.documentElement && document.documentElement.clientWidth){
                x = document.documentElement.clientWidth;
        }else if (document.body){
                x = document.body.clientWidth;
        }

        return x;
    }
            

    /*retorna el alto de la pagina*/
    function getHeight()
    {
        var y = 0;
        if (self.innerHeight){
            y = self.innerHeight;
        }else if (document.documentElement && document.documentElement.clientHeight){
            y = document.documentElement.clientHeight;
        }else if (document.body){
            y = document.body.clientHeight;
        }

        return y;
    }
</script>

    </head>
    <body onresize="resize();">
        <div class="titulo">
            Virtual Line <div class="status"></div>
        </div>

        <div align="center">
            <div id="info" style="height:228px;border:0px solid;">
                <div id="contenido" style="display: none">

                <p>Mi número de atención <div class="dato" id="miNumero"><?php echo $letra ." ". $miNumero; ?></div></p>

                <div class="form">
                    <table width="100%" border="0"> 
                        <tr>
                            <td width="48%" align="center">Atendiendo al</td>
                            <td width="20px"></td>
                            <td width="48%" align="center">En el módulo</td>
                        </tr>

                        <tr>
                            <td align="center"><div class="dato" id="idNumero"></td>
                            <td width="20px"></td>
                            <td align="center"><div class="dato" id="idMiModulo"></div></td>
                        </tr>

                    </table>
                </div>
                <p id="suturno" ></p>
                </div>
            </div>
        </div>
            
        <div class="publi" id="publi">
            Copyright © 2015 - <a href="http://www.selenit.cl">www.selenit.cl</a>
        </div>
    </body>
</html>
