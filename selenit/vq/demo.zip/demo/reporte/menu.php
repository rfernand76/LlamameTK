                    <li id="report.filas.global.menu"> <a href="report.filas.global.menu.php"> Filas</a>
                      <ul>
                        <li><a href="report.filas.solicitudes.menu.php"> Resumen Solicitudes</a></li>
                        <li><a href="report.filas.atendidas.menu.php"> Resumen Atenciones</a></li>
                        <li><a href="report.filas.detalle.menu.php"> Detalle Solicitudes</a></li>
                      </ul>                    
                    </li>
                    <li id="report.usuarios.global.menu"> <a href="report.usuarios.global.menu.php"> Usuarios</a>
                      <ul>
                        <li><a href="report.usuarios.pausa.menu.php"> Resumen pausas</a></li>
                      </ul>                    

                    </li>

                    <!--li id="mas"> <a  class="menuico_home"><img src="../css/images/mas.png"/> Mas reportes</a>
                      <ul>
                        <li><a href="#">Horarios</a></li>
                        <li><a href="#">Intervalos</a></li>
                        <li><a href="#">Mayor produccion</a></li>
		                <li><a href="#">Menor Produccion</a></li>
                 		<li><a href="#">Reclutamiento</a></li>
                      </ul>                    
                    </li-->
