	<?php  
        include("../global/virtualQueueIni.php");
        $cfg = VirtualQueueIni::getInstance();
    
	    $link = mysql_connect($cfg->getServer(), $cfg->getUsername(), $cfg->getPassword());
	    if (!$link) {
            die('Not connected : ' . mysql_error());
        }

		// make foo the current db

		$db_selected = mysql_select_db($cfg->getDatabase(), $link);


		$nemo=$_GET["nemo"];

        $sql = "select fil_ta, fil_ut from fila WHERE fil_nemo='$nemo'";
		$result = mysql_query($sql);
        $fila = mysql_fetch_assoc($result);
        $fil_ta = $fila["fil_ta"];

        echo $fil_ta;
        mysql_close($link);

	?>
