	<?php  
        include("../global/virtualQueueIni.php");
        $cfg = VirtualQueueIni::getInstance();
    
	    $link = mysql_connect($cfg->getServer(), $cfg->getUsername(), $cfg->getPassword());
		if (!$link) {
			die('Not connected : ' . mysql_error());
		}
		
		// make foo the current db
		$db_selected = mysql_select_db($cfg->getDatabase(), $link);
		if (!$db_selected) {
			die ('Can\'t use foo : ' . mysql_error());
		}


		$nemo=$_GET["nemo"];
        $modulo=$_GET["modulo"];
        $numero=$_GET["numero"];

		$sql = "UPDATE fila SET fil_ta='$numero', eje_modulo='$modulo' WHERE fil_nemo='$nemo'";
		mysql_query($sql);


        mysql_close($link);

	?>
