<!DOCTYPE html>
<html lang="en">
<head>
<title>Selenit - Menu inicio</title>
<meta name="description" content="Menu inicio"/>
<meta charset="utf-8">

<link rel="stylesheet" href="/js/vui/visualUI.css"/>
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">

<script type="text/javascript">
</script>

</head>
<body>
    <div id="wrapper">
      <div class="shell">
        <div class="container">
            <header class="header">
              <h1 id="logo"></h1>
              <div class="cl">&nbsp;</div>
            </header>

            <section>
                <h1>Sistema de administracion de filas<h1/>
            </section>

            <section class="box">
                <a href='ejecutivo'>Ejecutivo</a><br />
                <a href='dispensador'>Dispensador</a><br />
                <a href='reporte'>Reporte</a><br />
                <a href='adm'>Administracion</a><br />
                <a href='monitor'>Monitor</a><br />
                <a href='seguimiento'>Seguimientojs</a><br />
                <span class="shadow-b"></span> </div>
            </section>
        </div>
      </div>
    </div>


</div>
</body>
</html>
